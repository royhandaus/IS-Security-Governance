// server.js
const http = require("http");
const socketIo = require("socket.io");

const server = http.createServer();
const io = socketIo(server);

const users = new Map(); // username -> publicKeyPem

io.on("connection", (socket) => {
  console.log(`Client ${socket.id} connected`);

  // send current users (username, publicKey) to newly connected client
  socket.emit("init", Array.from(users.entries()));

  // register public key
  socket.on("registerPublicKey", (data) => {
    const { username, publicKey } = data;
    users.set(username, publicKey);
    console.log(`${username} registered with public key.`);
    io.emit("newUser", { username, publicKey });
  });

  // simple broadcast message (server DOES NOT verify signatures - it's just relay)
  socket.on("message", (data) => {
    // expect { displayName, message, signer, signature }
    io.emit("message", data);
  });

  socket.on("disconnect", () => {
    console.log(`Client ${socket.id} disconnected`);
  });
});

const port = 3000;
server.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
