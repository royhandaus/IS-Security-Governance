// client.js
const io = require("socket.io-client");
const readline = require("readline");
const crypto = require("crypto");

const socket = io("http://localhost:3000");

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
    prompt: "> ",
});

let registeredUsername = "";
let displayName = ""; // current name to display (can impersonate)
const users = new Map(); // username -> publicKeyPem

// generate RSA key pair (2048)
const { publicKey, privateKey } = crypto.generateKeyPairSync("rsa", {
    modulusLength: 2048,
    publicKeyEncoding: { type: "pkcs1", format: "pem" },
    privateKeyEncoding: { type: "pkcs1", format: "pem" },
});

// helper: sign a message (signer: registeredUsername)
function signMessage(signer, message) {
    const signerString = `${signer}:${message}`;
    const sign = crypto.createSign("sha256");
    sign.update(signerString);
    sign.end();
    const signature = sign.sign(privateKey, "base64");
    return signature;
}

// helper: verify signature (verifySigner = username whose public key we will use)
function verifySignature(verifySigner, message, signatureBase64) {
    const pub = users.get(verifySigner);
    if (!pub) return false; // don't have public key to verify
    const verify = crypto.createVerify("sha256");
    verify.update(`${verifySigner}:${message}`);
    verify.end();
    try {
        return verify.verify(pub, signatureBase64, "base64");
    } catch (e) {
        return false;
    }
}

socket.on("connect", () => {
    console.log("Connected to the server");

    rl.question("Enter your username: ", (input) => {
        registeredUsername = input || "Anonymous";
        displayName = registeredUsername;
        console.log(`Welcome, ${registeredUsername} to the chat`);

        // register public key with server
        socket.emit("registerPublicKey", {
            username: registeredUsername,
            publicKey: publicKey, // pem string
        });

        rl.prompt();

        rl.on("line", (line) => {
            const message = line.trim();
            if (!message) {
                rl.prompt();
                return;
            }

            // commands: impersonate and exit
            const impMatch = message.match(/^!impersonate (\w+)$/);
            if (impMatch) {
                displayName = impMatch[1];
                console.log(`Now impersonating as ${displayName} (messages still signed by ${registeredUsername})`);
                rl.prompt();
                return;
            } else if (message === "!exit") {
                displayName = registeredUsername;
                console.log(`Now you are ${displayName}`);
                rl.prompt();
                return;
            }

            // normal send: sign using own private key; signer = registeredUsername (always)
            const signer = registeredUsername;
            const signature = signMessage(signer, message);

            // payload includes displayName (who we want to appear as), actual signer, and signature
            socket.emit("message", {
                displayName,
                message,
                signer,
                signature,
            });

            rl.prompt();
        });
    });
});

// receive init (existing users and their public keys)
socket.on("init", (keys) => {
    keys.forEach(([user, key]) => users.set(user, key));
    console.log(`\nThere are currently ${users.size} users in the chat`);
    rl.prompt();
});

// new user joined (registered their public key)
socket.on("newUser", (data) => {
    const { username, publicKey } = data;
    users.set(username, publicKey);
    console.log(`${username} joined the chat`);
    rl.prompt();
});

// incoming messages
socket.on("message", (data) => {
    // { displayName, message, signer, signature }
    const { displayName: claimedName, message: msg, signer, signature } = data;

    // Try verify using signer's public key (must have been registered)
    const hasPub = users.has(signer);

    if (!hasPub) {
        console.log(`[WARNING] Unknown signer ${signer}. Could not verify. Message from ${claimedName}: ${msg}`);
        rl.prompt();
        return;
    }

    const ok = verifySignature(signer, msg, signature);

    if (!ok) {
        console.log(`[WARNING] this user is fake (signature invalid) — message from ${claimedName}`);
        console.log(`[forger?] ${claimedName}: ${msg}`);
        rl.prompt();
        return;
    }

    // signature valid
    if (signer !== claimedName) {
        // signed by someone else but claimed a different displayName -> impersonation
        console.log(`[WARNING] this user is fake (impersonation detected). Signed by ${signer} but displayed as ${claimedName}`);
        console.log(`[${claimedName}] (IMP) ${msg}`);
        rl.prompt();
        return;
    }

    // all good
    // show message normally
    if (signer === registeredUsername) {
        // if the message is our own message, optionally skip or show
        // we'll show it for transparency
        console.log(`${claimedName} (you): ${msg}`);
    } else {
        console.log(`${claimedName}: ${msg}`);
    }
    rl.prompt();
});

socket.on("disconnect", () => {
    console.log("Server disconnected, Exiting...");
    rl.close();
    process.exit(0);
});

process.on("SIGINT", () => {
    console.log("\nExiting...");
    socket.disconnect();
    rl.close();
    process.exit(0);
});
