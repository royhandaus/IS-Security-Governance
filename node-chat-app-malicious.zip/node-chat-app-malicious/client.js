// client.js (client dengan verifikasi hash)
const io = require("socket.io-client");
const readline = require("readline");
const crypto = require("crypto");

const socket = io("http://localhost:3000");

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
    prompt: "> ",
});

let username = "";

// helper: hitung SHA-256 hex dari string
function sha256hex(text) {
    return crypto.createHash("sha256").update(text, "utf8").digest("hex");
}

socket.on("connect", () => {
    console.log("Connected to the server");

    rl.question("Enter your username: ", (input) => {
        username = input || "Anonymous";
        console.log(`Welcome, ${username} to the chat`);
        rl.prompt();

        // listen for lines once username sudah ada
        rl.on("line", (message) => {
            if (message.trim()) {
                const hash = sha256hex(message);
                // kirim message + hash ke server
                socket.emit("message", { username, message, hash });
            }
            rl.prompt();
        });
    });
});

// menerima pesan dari server
socket.on("message", (data) => {
    // expect { username, message, hash }
    const { username: senderUsername, message: senderMessage, hash: sentHash } = data;

    // hitung hash dari message yang kita terima
    const calcHash = sha256hex(senderMessage);

    if (sentHash && calcHash !== sentHash) {
        // ada mismatch -> beri peringatan
        console.log(`[WARNING] the message may have been changed during transmission`);
        console.log(`[${senderUsername}] (tampered): ${senderMessage}`);
    } else {
        // aman / sesuai
        // jika pengirim sendiri, kita bisa skip atau tetap tampilkan (pilih tampilkan untuk transparansi)
        console.log(`${senderUsername}: ${senderMessage}`);
    }

    rl.prompt();
});

socket.on("disconnect", () => {
    console.log("Server disconnected, Exiting...");
    rl.close();
    process.exit(0);
});

// graceful exit
process.on("SIGINT", () => {
    console.log("\nExiting...");
    socket.disconnect();
    rl.close();
    process.exit(0);
});
