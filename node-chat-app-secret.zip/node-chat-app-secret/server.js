// server.js
const http = require("http");
const socketIo = require("socket.io");

const server = http.createServer();
const io = socketIo(server);

// store registered users' public keys
// Map<username, publicKeyPem>
const users = new Map();

io.on("connection", (socket) => {
    console.log(`Client ${socket.id} connected`);

    // send current users + public keys to new client
    socket.emit("init", Array.from(users.entries()));

    // register public key from client
    socket.on("registerPublicKey", (data) => {
        const { username, publicKey } = data;
        if (username && publicKey) {
            users.set(username, publicKey);
            console.log(`${username} registered with public key.`);
            // notify all clients a new user joined / updated
            io.emit("newUser", { username, publicKey });
        }
    });

    // simple broadcast for normal chat messages
    socket.on("message", (data) => {
        // data expected: { username, message }
        io.emit("message", data);
    });

    // relay secret (encrypted) messages unchanged
    socket.on("secretMessage", (data) => {
        // data expected: { sender, receiver, ciphertext }
        io.emit("secretMessage", data);
    });

    socket.on("disconnect", () => {
        console.log(`Client ${socket.id} disconnected`);
    });
});

const port = 3000;
server.listen(port, () => {
    console.log(`Server running on port ${port}`);
});
