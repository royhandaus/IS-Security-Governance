const io = require("socket.io-client");
const readline = require("readline");
const crypto = require("crypto");

const socket = io("http://localhost:3000");

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
    prompt: "> ",
});

// ===========================
//  RSA Key Generation
// ===========================
const { publicKey, privateKey } = crypto.generateKeyPairSync("rsa", {
    modulusLength: 2048,
});

let username = "";
let targetUsername = "";
const users = new Map(); // store username => publicKey

socket.on("connect", () => {
    console.log("Connected to the server");

    rl.question("Enter your username: ", (input) => {
        username = input;
        console.log(`Welcome, ${username} to the chat`);

        socket.emit("registerPublicKey", {
            username,
            publicKey: publicKey.export({ type: "pkcs1", format: "pem" }),
        });

        rl.prompt();

        // ===========================
        //   HANDLE INPUT PER LINE
        // ===========================
        rl.on("line", (message) => {
            if (!message.trim()) return;

            // Command untuk mulai secret chat
            if ((match = message.match(/^!secret (\w+)$/))) {
                targetUsername = match[1];
                console.log(`🔐 Now secretly chatting with ${targetUsername}`);
            }

            // Keluar dari secret mode
            else if (message === "!exit") {
                console.log(`🚫 No more secret chat with ${targetUsername}`);
                targetUsername = "";
            }

            // Mode Secret Chat (Encrypt before sending)
            else if (targetUsername !== "") {
                if (!users.has(targetUsername)) {
                    console.log("❌ Target user not found / not online");
                } else {
                    const targetPublicKey = users.get(targetUsername);

                    const encryptedMessage = crypto.publicEncrypt(
                        targetPublicKey,
                        Buffer.from(message, "utf8")
                    );

                    socket.emit("secretMessage", {
                        sender: username,
                        receiver: targetUsername,
                        ciphertext: encryptedMessage.toString("base64"),
                    });

                    console.log(`📤 Encrypted Message sent to ${targetUsername}`);
                }
            }

            // Normal broadcast message
            else {
                socket.emit("message", { username, message });
            }

            rl.prompt();
        });
    });
});

// ===========================
//  RECEIVE USERS + PUBLIC KEYS
// ===========================
socket.on("init", (keys) => {
    keys.forEach(([user, key]) => users.set(user, key));
    console.log(`\nThere are ${users.size} users connected`);
    rl.prompt();
});

socket.on("newUser", (data) => {
    const { username, publicKey } = data;
    users.set(username, publicKey);
    console.log(`${username} joined the chat`);
    rl.prompt();
});

// ===========================
//  RECEIVE NORMAL MESSAGE
// ===========================
socket.on("message", (data) => {
    const { username: sender, message } = data;
    if (sender !== username) console.log(`${sender}: ${message}`);
    rl.prompt();
});

// ===========================
//  RECEIVE SECRET MESSAGE
// ===========================
socket.on("secretMessage", (data) => {
    const { sender, ciphertext } = data;

    try {
        const decrypted = crypto.privateDecrypt(
            privateKey,
            Buffer.from(ciphertext, "base64")
        );

        console.log(`\n🔓 Secret message from ${sender}: ${decrypted.toString()}`);
    } catch (err) {
        console.log(`\n⚠️ Encrypted message received (not for you)`);
    }

    rl.prompt();
});

// ===========================
//  DISCONNECT HANDLING
// ===========================
socket.on("disconnect", () => {
    console.log("\nServer disconnected. Exiting...");
    rl.close();
    process.exit(0);
});

rl.on("SIGINT", () => {
    console.log("\nExiting...");
    socket.disconnect();
    rl.close();
    process.exit(0);
});
